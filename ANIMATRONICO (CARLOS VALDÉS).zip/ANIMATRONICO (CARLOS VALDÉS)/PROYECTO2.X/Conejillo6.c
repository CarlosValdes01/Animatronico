/* 
 * Archivo: Proyecto animatronico.c
 * Dispositivo: PIC16F887
 * Autor: Carlos Julio Vald�s Oajaca
 * Compilador: XC8, MPLABX v6.05
 
 * Programa: Animatronico con 4 modos: manual, EEPROM, UART, Adafruit
 * Hardware: Potenciometros, botones, servomotores

 * Creado: 13 de mayo, 2023
 * �ltima modificaci�n: 30 de mayo, 2023
 */

// PIC16F887 Configuration Bit Settings
// 'C' source line config statements
// CONFIG1
#pragma config FOSC = INTRC_NOCLKOUT// Oscillator Selection bits (INTOSCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, I/O function on RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = OFF      // RE3/MCLR pin function select bit (RE3/MCLR pin function is digital input, MCLR internally tied to VDD)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal/External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)
#pragma config LVP = OFF        // Low Voltage Programming Enable bit (RB3 pin has digital I/O, HV on MCLR must be used for programming)

// CONFIG2
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)
// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include <pic16f887.h>
#include <xc.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

///////////////////////////////////DEFINIR CONSTANTES///////////////////////////////////////////////////////////////////////////////////
#define _XTAL_FREQ 8000000 //8MHz
////////////////////////////////////VARIABLES GLOBALES/////////////////////////////////////////////////////////////////////////////////
uint8_t contador;
uint8_t modo;
uint8_t POT_1;
uint8_t POT_2;
uint8_t POT_3;
uint8_t mapPot3;
uint8_t POT_4;
uint8_t mapPot4;
uint8_t POT_EEPROM;
uint8_t valor_EEPROM1;
uint8_t valor_EEPROM2;
uint8_t valor_EEPROM3;
uint8_t valor_EEPROM4;
/////////////////////////////////////PROTOTIPOS DE FUNCIONES///////////////////////////////////////////////////////////////////////////
void setup(void);
void initUART(void);
uint8_t read_EEPROM(uint8_t address);
void write_EEPROM(uint8_t address, uint8_t data);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

uint8_t MAP(uint8_t au32_IN, uint8_t au32_INmin, uint8_t au32_INmax, uint8_t au32_OUTmin, uint8_t au32_OUTmax)
{
    return ((((au32_IN - au32_INmin)*(au32_OUTmax - au32_OUTmin))/(au32_INmax - au32_INmin)) + au32_OUTmin);
}

/////////////////////////////////////INTERRUPCIONES//////////////////////////////////////////////////////////////////////////////////
void __interrupt() isr(void)
{
  if (INTCONbits.T0IF){ //interrupcion del tmr0   poner if de modo?
      TMR0 = 231;
      INTCONbits.T0IF = 0;
      
      contador++;//aumentar la variable de contador
      if (contador > 100){
          contador=0;
      }
      if (contador < mapPot3)  //hacer la comparacion si ya llego al mismo valot del POT
          PORTCbits.RC4 = 1;
      else 
          PORTCbits.RC4 = 0;
      
      if (contador < mapPot4)
          PORTCbits.RC5 = 1;
      else 
          PORTCbits.RC5 = 0;
  }
  
   if (PIR1bits.ADIF) //Interrupcion del ADC
  { 
        if (ADCON0bits.CHS == 4){
    
            POT_1 = ADRESH;
        }
        else if (ADCON0bits.CHS == 5){
            POT_2 = ADRESH;
        }
        else if (ADCON0bits.CHS == 6){ 
            POT_3 = ADRESH;    
        }
        else{
            POT_4 = ADRESH;}
    PIR1bits.ADIF = 0;
  }
   if(PIR1bits.RCIF)            //Datos recibidos?
            {   //if (modo == 4){ //Serial en modo 4 unicamente   
                    if (RCREG == '1'){ //pierna izq hacia afuera
                    CCPR2L = 245;
                    }
                    if (RCREG == '2'){ //pierna izq hacia adentro
                    CCPR2L = 115;
                    }
                    if (RCREG == '3'){ //pierna der hacia afuera
                    CCPR1L = 115;
                    }
                    if (RCREG == '4'){ //pierna der hacia adentro
                    CCPR1L = 245;
                    }
                
                    if (RCREG == '5'){ //pie izq hacia arriba
                    mapPot4 = 4;
                    }
                        if (RCREG == '6'){ //pie izq hacia abajo
                    mapPot4 = 12;
                    }
                    if (RCREG == '7'){ //pie der hacia arriba
                    mapPot3 = 12;
                    }
                    if (RCREG == '8'){ //pie der hacia abajo
                    mapPot3 = 4;
                    }
                //}
                /*else{
                    ;
                }*/
                PIR1bits.RCIF = 0;
            }
  
}
///////////////////////////////////////CODIGO PRINCIPAL/////////////////////////////////////////////////////////////////////
void main(void){
    setup();    //llamar a la configuracion
    initUART(); //llamar inicializacion de UART
    ADCON0bits.GO = 1;
 ////LOOP PRINCIPAL/////   
    while(1) //Loop infinito
    {   
        if(PORTBbits.RB0 == 0){
            __delay_ms(100);          //antirebote
            if (PORTBbits.RB0 == 0){
                modo++;              //cambiar de modo
                if (modo > 4){
                modo = 0;}
            }
        }
        __delay_ms(5);
        if (ADCON0bits.GO == 0) //Realizar la verificacion para las conversiones
        {    
            if (ADCON0bits.CHS == 4)
                ADCON0bits.CHS = 5;

            else if (ADCON0bits.CHS == 5)
                ADCON0bits.CHS = 6;

            else if (ADCON0bits.CHS == 6)
                ADCON0bits.CHS = 7;

            else if (ADCON0bits.CHS == 7)
                ADCON0bits.CHS = 4;
            __delay_ms(5);    
            ADCON0bits.GO = 1;
        }
        
        if (modo == 1){        //MODO MANUAL
            PORTDbits.RD0 = 1; //indica modo manual
            PORTDbits.RD1 = 0;
            PORTDbits.RD2 = 0;
            PORTDbits.RD3 = 0;
            PORTDbits.RD4 = 0;
             
            mapPot4 = MAP(POT_4, 0, 255, 2, 13); //mapeo
            mapPot3 = MAP(POT_3, 0, 255, 2, 13);
            CCPR2L = MAP(POT_2,  0, 255, 60, 252);
            CCPR1L = MAP(POT_1,  0, 255, 60, 252);     
       }
        
        if (modo == 2){        //MODO ESCRITURA EEPROM
            PORTDbits.RD0 = 0; 
            PORTDbits.RD1 = 1; //indica salvar en EEPROM
            PORTDbits.RD2 = 0;
            PORTDbits.RD3 = 0;
            PORTDbits.RD4 = 0;
            
            write_EEPROM(0x00, POT_1);
            __delay_us(100);
            write_EEPROM(0x01, POT_2);
            __delay_us(100);
            write_EEPROM(0x02, POT_3);
            __delay_us(100);
            write_EEPROM(0x03, POT_4);
            __delay_us(100);
        }
        
        if (modo == 3){       //MODO LECTURA EEPROM
            PORTDbits.RD0 = 0; 
            PORTDbits.RD1 = 0; 
            PORTDbits.RD2 = 1; //indica leer de EEPROM
            PORTDbits.RD3 = 0;
            PORTDbits.RD4 = 0;
            
            valor_EEPROM1 = read_EEPROM(0x00);
            __delay_us(100);
            valor_EEPROM2 = read_EEPROM(0x01);
            __delay_us(100);
            valor_EEPROM3 = read_EEPROM(0x02);
            __delay_us(100);
            valor_EEPROM4 = read_EEPROM(0x03);
            __delay_us(100);
        
            mapPot4 = MAP(valor_EEPROM1, 0, 255, 2, 13); //mapeo
            mapPot3 = MAP(valor_EEPROM2, 0, 255, 2, 13);
            CCPR2L = MAP(valor_EEPROM3,  0, 255, 60, 252);
            CCPR1L = MAP(valor_EEPROM4,  0, 255, 60, 252);
        }
        
        if (modo == 4){       //MODO UART
            PORTDbits.RD0 = 0; 
            PORTDbits.RD1 = 0; 
            PORTDbits.RD2 = 0;
            PORTDbits.RD3 = 1; //indica modo UART
            PORTDbits.RD4 = 0; 
///////////////////de momento en main para ver si funciona
            /*if(PIR1bits.RCIF)            //Datos recibidos?
            {    
                if (RCREG == '1'){
                    CCPR2L = 252;
                }
                if (RCREG == '2'){
                    CCPR2L = 60;
                }
                if (RCREG == '3'){
                    CCPR2L = 60;
                }
                if (RCREG == '4'){
                    CCPR2L = 252;
                }
                
                if (RCREG == '5'){
                    mapPot4 = 13;
                }
                if (RCREG == '6'){
                    mapPot4 = 2;
                }
                if (RCREG == '7'){
                    mapPot4 = 2;
                }
                if (RCREG == '8'){
                    mapPot4 = 13;
                }
                PIR1bits.RCIF = 0;
            }*/
        }
        
    }
    //return;
}

//////////////////////////////////////SETUP/////////////////////////////////////////////////////////////////////
void setup(void)
{
    //configuracion de pines y puertos    
    ANSEL= 0b11110000;  //An activos AN 4 , 5, 6, 7
    ANSELH= 0; //configura los pines de portB como digital
    
    TRISBbits.TRISB0 = 1; //Configurar entradas de los push-buttons
    
    TRISEbits.TRISE0 = 1; //Configurar entradas de los POT
    TRISEbits.TRISE1 = 1;
    TRISEbits.TRISE2 = 1;
    TRISAbits.TRISA5 = 1;
    
    TRISCbits.TRISC4 = 0; //Salida de los POT manuales
    TRISCbits.TRISC5 = 0;
    
    TRISDbits.TRISD0 = 0; //LEDs
    TRISDbits.TRISD1 = 0;
    TRISDbits.TRISD2 = 0;
    TRISDbits.TRISD3 = 0;
    TRISDbits.TRISD4 = 0;
            
    //Inicializar los puertos en 0
    PORTA = 0;
    PORTB = 0;
    PORTE = 0;
    PORTC = 0;
    PORTD = 0;
    contador = 0;
    modo = 1;
    
    //Config pull-ups
    OPTION_REGbits.nRBPU = 0; //Habilitamos pull-up en B
    WPUBbits.WPUB0 = 1;       //Habilitamos pull-up en los pines deseados
    WPUBbits.WPUB1 = 1;
    WPUBbits.WPUB2 = 1;
    
    //configuracion oscilador
    OSCCONbits.IRCF = 0b0111; //8MHz
    OSCCONbits.SCS = 1;       //Utilizar el reloj interno
    
    //configuracion TMR0
    OPTION_REGbits.T0CS = 0;   //tmr0 como temporizador
    OPTION_REGbits.PSA = 0;    //presc al tmr0
    OPTION_REGbits.PS = 0b011; //presc 1:16
    TMR0 = 231;                  //cargar valor para = 0.2ms
    
    //configuracion del ADC
    ADCON1bits.ADFM = 0; //Justificado a la izquierda
    ADCON1bits.VCFG0 = 0; //Referencia en VDD
    ADCON1bits.VCFG1 = 0; //Referencia en VSS 
    
    ADCON0bits.ADCS = 0b10; //ADCS <1:0> -> 01 Fosc/32
    //ADCON0bits.CHS = 3;     //POT de la EEPROM
    ADCON0bits.CHS = 4;     //Canal para los POTs de los servos
    ADCON0bits.CHS = 5;     
    ADCON0bits.CHS = 6;
    ADCON0bits.CHS = 7;
    ADCON0bits.ADON = 1;    //Encender ADC
    __delay_us(50);
    
    //configuracion del PWM
    TRISCbits.TRISC2 = 1; // RC2_CCP1 como entrada
    TRISCbits.TRISC1 = 1; // RC1_CCP1 como entrada
    PR2 = 255;            //config periodo 2ms aprox
    
    CCP1CONbits.P1M = 0;  //config modo PWM de CCP1
    CCP1CONbits.CCP1M = 0b1100;
    
    //config modo PWM de CCP2
    CCP2CONbits.CCP2M = 0b1100;
    
    CCPR1L = 0x0F; //ciclo de trabajo inicial CCP1
    CCP1CONbits.DC1B = 0;
    
    CCPR2L = 0x0F; //ciclo de trabajo inicial CCP2
   // CCP2CONbits.DC2B0 = 0;
    CCP2CONbits.DC2B1 = 0;
    
    PIR1bits.TMR2IF = 0;     //inicializar bandera en 0
    T2CONbits.T2CKPS = 0b11; //presc de 1:16
    T2CONbits.TMR2ON = 1;
    
    while(PIR1bits.TMR2IF == 0); //esperamos 1 ciclo de tmr2
    PIR1bits.TMR2IF = 0;
    
    TRISCbits.TRISC2 = 0; //salida del PWM CCP1
    TRISCbits.TRISC1 = 0; //salida del PWM CCP2
    
    //IOCB's
    //IOCBbits.IOCB0 = 1;  //Habilitar interrupt-on change
    //IOCBbits.IOCB1 = 1;
    //IOCBbits.IOCB2 = 1;
    INTCONbits.RBIF = 0; //Inicializar bandera de portB en 0
    INTCONbits.RBIE = 0; //Habilitar interrupcion del PORTB
    
    //configuracion de interrupciones
    INTCONbits.TMR0IE = 1; //habilitar interrupcion del tmr0
    INTCONbits.T0IF = 0; //inicializar bandera de tmr0 en 0
    PIR1bits.ADIF = 0;   //Inicializar bandera en 0
    PIE1bits.ADIE = 1;   //Habilitar interrupciones del ADC
    INTCONbits.PEIE = 1; //Habilitar interrupciones perifericas
    INTCONbits.GIE = 1; // Habilita interrupciones generales

}
//////////////////////////////////////FUNCIONES/////////////////////////////////////////////////////////////////////
    void initUART(void)
    { //Configuracion de la comunicacion serial
    //Paso 1    
     SPBRG = 51;            //Calculo para aprox. 9600 Baud
     SPBRGH = 0;            //% error= 0.16%
     TXSTAbits.BRGH = 1;    //Baud rate de alta velocidad 
     BAUDCTLbits.BRG16 = 0; //Se utilizan 8 bits para Baud rate
    
    //Paso 2
     TXSTAbits.SYNC = 0;  //Comunicacion asincrona (full-duplex)
     RCSTAbits.SPEN = 1;  //Habilita comunicacion (modulo UART)
     
    //Paso 3: 9 bits
     TXSTAbits.TX9 = 0;   //Se utilizan solo 8 bits
     
    //Paso 4
     TXSTAbits.TXEN = 0;  //Habilitar Transmisor
     RCSTAbits.CREN = 1;  //Habilitar Receptor
     TXIF = 0; //apagar bandera TX
     
    PIE1bits.RCIE = 1;   //Habilitar interrupcion de Recepcion
    }
////////////////////////////////////////////////////////////////////////////////////    
uint8_t read_EEPROM(uint8_t address)
{
    EEADR = address;
    EECON1bits.EEPGD = 0; //Leer de la EEPROM
    EECON1bits.RD = 1;    //Obtener dato de la EEPROM
    return EEDAT;        //Regresar el dato
}        
///////////////////////////////////////////////////////////////////////////////////
void write_EEPROM(uint8_t address, uint8_t data)
{   while(WR);
    EEADR = address;
    EEDAT = data;
    EECON1bits.WREN = 1;  //Habilitar escritura de la EEPROM
    EECON1bits.EEPGD = 0; //Escritura de la EEPROM
    
    INTCONbits.GIE = 0;   //Deshabilitar interrupciones globales
    EECON2 = 0x55;
    EECON2 = 0xAA;
    EECON1bits.WR = 1;    //Iniciar escritura
    
    while(PIR2bits.EEIF == 0);
    PIR2bits.EEIF = 0;
    EECON1bits.WREN = 0;  //Deshabilitar escritura de la EEPROM
    INTCONbits.RBIF = 0;
    INTCONbits.GIE = 1;
}
