"""
'digital_in.py'
==================================
Example of sending button values
to an Adafruit IO feed.
Author(s): Brent Rubell, Todd Treece
"""
# Import standard python modules
import time

#Importar para leer del puerto serial
import serial

# import Adafruit Blinka
#import board
#import digitalio

# import Adafruit IO REST client.
from Adafruit_IO import Client, Feed

# Set to your Adafruit IO key.
# Remember, your key is a secret,
# so make sure not to publish it when you publish this code!
ADAFRUIT_IO_KEY = 'aio_Qiyq95fgOSGYM2zTSRoj3gJ7bVfZ'

# Set to your Adafruit IO username.
# (go to https://accounts.adafruit.com to find your username)
ADAFRUIT_IO_USERNAME = 'CarlosJV'

# Create an instance of the REST client.
aio = Client(ADAFRUIT_IO_USERNAME, ADAFRUIT_IO_KEY)

#Feed name
ottos1 = aio.feeds('ottos1')
ottos2 = aio.feeds('ottos2')
ottos3 = aio.feeds('ottos3')
#otto4 = aio.feeds('otto4')
ottos5 = aio.feeds('ottos5')
#ottos6 = aio.feeds('ottos6')
#ottos7 = aio.feeds('ottos7')
#ottos8 = aio.feeds('ottos8')

# Leer del PIC (contador)--------------------------------------------------------

# Configuración del puerto serial
ser = serial.Serial('COM4', 9600)

#-----------------------------------------------------------------------------------

while True:
    
    #data = ser.read().decode(encoding="utf-8", errors="replace").strip()
    #print('Button -> ', data)
    #aio.send(ottos1.key, data)

    out1 = aio.receive(ottos1.key)
    ser.write((out1.value).encode('utf-8'))
    print(out1)

    out2 = aio.receive(ottos2.key)
    ser.write((out2.value).encode('utf-8'))
    print(out2)

    out3 = aio.receive(ottos3.key)
    ser.write((out3.value).encode('utf-8'))
    print(out3)

    #out4 = aio.receive(otto4.key)
    #ser.write((out4.value).encode('utf-8'))
    #print(out4)

    out5 = aio.receive(ottos5.key)
    ser.write((out5.value).encode('utf-8'))
    print(out5)

    #out6 = aio.receive(ottos6.key)
    #ser.write((out6.value).encode('utf-8'))
    #print(out6)

    #out7 = aio.receive(ottos7.key)
    #ser.write((out7.value).encode('utf-8'))
    #print(out7)

    #out8 = aio.receive(ottos8.key)
    #ser.write((out8.value).encode('utf-8'))
    #print(out8)


    # avoid timeout from adafruit io
    time.sleep(0.5)